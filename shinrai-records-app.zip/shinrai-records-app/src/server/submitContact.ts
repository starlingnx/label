import { createServerFn } from '@tanstack/react-start'

export type ContactMessage = {
  name: string
  email: string
  message: string
}

export const submitContactFn = createServerFn({ method: 'POST' })
  .validator((data: ContactMessage) => data)
  .handler(async ({ data }) => {
    // Same TODO as submitDemo.ts — wire this to a real email/form service
    // before launch. See .env.example.
    console.log('[contact message]', data)
    return { ok: true as const }
  })
