import { createServerFn } from '@tanstack/react-start'

export type DemoSubmission = {
  name: string
  artistName: string
  email: string
  trackLink: string
  genre: string
  notes: string
}

export const submitDemoFn = createServerFn({ method: 'POST' })
  .validator((data: DemoSubmission) => data)
  .handler(async ({ data }) => {
    // This currently only logs on the server — it does not reach anyone's
    // inbox yet. Real submissions need one of:
    //   1. An email API (Resend, Postmark, SendGrid) — call it here with
    //      your API key from an env var, sending to
    //      support.shinrairecords@gmail.com.
    //   2. A form backend (Formspree, Basin) — POST `data` to their endpoint
    //      instead of console.log below.
    // See .env.example for where a RESEND_API_KEY (or similar) would go.
    console.log('[demo submission]', data)
    return { ok: true as const }
  })
