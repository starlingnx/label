export default function Footer() {
  return (
    <footer>
      <div className="container foot-row">
        <span className="word" style={{ fontSize: '.95rem' }}>
          SHINRAI <em>RECORDS</em>
        </span>
        <span>© 2026 Shinrai Records Music Group. All rights reserved.</span>
      </div>
    </footer>
  )
}
