import type { ReactNode } from 'react'

export default function SectionHeading({
  title,
  subtitle,
}: {
  title: ReactNode
  subtitle?: string
}) {
  return (
    <div className="s-head">
      <div>
        <div className="s-title">{title}</div>
        {subtitle && <div className="s-sub">{subtitle}</div>}
      </div>
    </div>
  )
}
