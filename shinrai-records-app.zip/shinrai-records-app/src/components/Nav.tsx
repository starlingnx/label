import { useState } from 'react'
import { Link } from '@tanstack/react-router'

const links = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/artists', label: 'Artists' },
  { to: '/contact', label: 'Contact' },
]

export default function Nav() {
  const [open, setOpen] = useState(false)

  return (
    <header>
      <div className="container nav">
        <Link to="/" className="word">
          SHINRAI <em>RECORDS</em>
        </Link>
        <nav className="nav-links" aria-label="Primary">
          {links.map((l) => (
            <Link key={l.to} to={l.to} activeProps={{ className: 'active' }} activeOptions={{ exact: l.to === '/' }}>
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="nav-right">
          <Link to="/submit-demo" className="pill-btn">
            Submit Demo
          </Link>
          <button
            className="burger"
            aria-label="Open menu"
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
          >
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </div>

      <div className={`drawer${open ? ' open' : ''}`}>
        {links.map((l) => (
          <Link key={l.to} to={l.to} onClick={() => setOpen(false)}>
            {l.label}
          </Link>
        ))}
        <Link to="/submit-demo" onClick={() => setOpen(false)}>
          Submit Demo
        </Link>
      </div>
    </header>
  )
}
