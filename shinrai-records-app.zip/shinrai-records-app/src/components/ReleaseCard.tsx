import type { Card } from '../data'

export default function ReleaseCard({ t, a, g, c }: Card) {
  return (
    <div className="card">
      <div className={`art ${c}`}>
        <span className="art-tag">{g}</span>
      </div>
      <div className="card-body">
        <div className="card-title">{t}</div>
        <div className="card-sub">{a}</div>
      </div>
    </div>
  )
}
