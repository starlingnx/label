import { useEffect, useRef, useState } from 'react'

function fmt(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M'
  if (n >= 1_000) return Math.round(n / 1_000) + 'K'
  return String(n)
}

export default function StatCounter({ target, label }: { target: number; label: string }) {
  const ref = useRef<HTMLDivElement>(null)
  const [value, setValue] = useState(0)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return
          observer.unobserve(el)
          if (reduce) {
            setValue(target)
            return
          }
          const dur = 1400
          let start: number | null = null
          function step(ts: number) {
            if (start === null) start = ts
            const p = Math.min((ts - start) / dur, 1)
            setValue(Math.floor(target * (1 - Math.pow(1 - p, 3))))
            if (p < 1) requestAnimationFrame(step)
          }
          requestAnimationFrame(step)
        })
      },
      { threshold: 0.4 },
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [target])

  return (
    <div>
      <div className="stat-num" ref={ref}>
        {fmt(value)}
      </div>
      <div className="stat-label">{label}</div>
    </div>
  )
}
