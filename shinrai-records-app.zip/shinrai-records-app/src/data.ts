export type Card = { t: string; a: string; g: string; c: string }
export type Artist = { n: string; g: string; c: string }

export const releases: Card[] = [
  { t: 'Night Drive', a: 'Kaito Rae', g: 'PHONK', c: 'g1' },
  { t: 'Slow Motion', a: 'Vega Sol', g: 'FUNK', c: 'g2' },
  { t: 'Neon Static', a: 'Mirei', g: 'PHONK', c: 'g3' },
  { t: 'Groove Theory', a: 'Dust Collective', g: 'FUNK', c: 'g4' },
  { t: 'After Hours', a: 'Ren Volta', g: 'FUSION', c: 'g5' },
  { t: 'Low End', a: 'Nova Haze', g: 'PHONK', c: 'g1' },
]

export const playlists: Card[] = [
  { t: 'Late Night Funk', a: '42 tracks', g: 'FUNK', c: 'g2' },
  { t: 'Phonk Essentials', a: '31 tracks', g: 'PHONK', c: 'g4' },
  { t: 'Shinrai Radio', a: 'Weekly update', g: 'MIXED', c: 'g5' },
]

export const artists: Artist[] = [
  { n: 'Kaito Rae', g: 'Phonk', c: 'g1' },
  { n: 'Vega Sol', g: 'Funk', c: 'g2' },
  { n: 'Mirei', g: 'Phonk', c: 'g3' },
  { n: 'Dust Collective', g: 'Funk', c: 'g4' },
  { n: 'Ren Volta', g: 'Fusion', c: 'g5' },
  { n: 'Nova Haze', g: 'Phonk', c: 'g1' },
]

export const partners: string[] = [
  'WAVEFORM DISTRO',
  'NEON SESSIONS',
  'AFTERDARK RADIO',
  'AMPLIFY MEDIA',
  'AUXILIARY SOUND',
  'ASCEND STUDIOS',
]

export const stats = [
  { target: 2_400_000, label: 'Total Streams' },
  { target: 38, label: 'Releases' },
  { target: 140_000, label: 'Social Reach' },
]
