import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useRef, useState } from 'react'
import { useReveal } from '../hooks/useReveal'
import { submitDemoFn } from '../server/submitDemo'

export const Route = createFileRoute('/submit-demo')({
  head: () => ({
    meta: [
      { title: 'Submit Demo — Shinrai Records' },
      { name: 'description', content: 'Send Shinrai Records your track — distribution, an 80/20 split, free cover art, and promo.' },
    ],
  }),
  component: SubmitDemo,
})

function SubmitDemo() {
  useReveal()
  const [toast, setToast] = useState<string | null>(null)
  const [sending, setSending] = useState(false)
  const timer = useRef<ReturnType<typeof setTimeout>>()

  function fireToast(msg: string) {
    setToast(msg)
    clearTimeout(timer.current)
    timer.current = setTimeout(() => setToast(null), 3200)
  }
  useEffect(() => () => clearTimeout(timer.current), [])

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget
    const data = {
      name: (form.elements.namedItem('dName') as HTMLInputElement).value,
      artistName: (form.elements.namedItem('dArtist') as HTMLInputElement).value,
      email: (form.elements.namedItem('dEmail') as HTMLInputElement).value,
      trackLink: (form.elements.namedItem('dLink') as HTMLInputElement).value,
      genre: (form.elements.namedItem('dGenre') as HTMLSelectElement).value,
      notes: (form.elements.namedItem('dNotes') as HTMLTextAreaElement).value,
    }
    setSending(true)
    try {
      // Reaches the server (see src/server/submitDemo.ts) — still needs a
      // real email/form service wired in before submissions actually
      // reach an inbox.
      await submitDemoFn({ data })
      fireToast("Demo received — we'll be in touch within two weeks.")
      form.reset()
    } catch {
      fireToast('Something went wrong — please try again.')
    } finally {
      setSending(false)
    }
  }

  return (
    <section className="page">
      <div className="container">
        <div className="s-title" data-reveal style={{ marginBottom: 40 }}>
          Submit Your <em>Demo</em>
        </div>
        <div className="split">
          <form data-reveal onSubmit={handleSubmit}>
            <div className="field">
              <label htmlFor="dName">Your Name</label>
              <input id="dName" name="dName" required />
            </div>
            <div className="field">
              <label htmlFor="dArtist">Artist Name</label>
              <input id="dArtist" name="dArtist" required />
            </div>
            <div className="field">
              <label htmlFor="dEmail">Email</label>
              <input id="dEmail" name="dEmail" type="email" required />
            </div>
            <div className="field">
              <label htmlFor="dLink">Track Link</label>
              <input id="dLink" name="dLink" type="url" placeholder="https://" required />
            </div>
            <div className="field">
              <label htmlFor="dGenre">Genre</label>
              <select id="dGenre" name="dGenre">
                <option>Phonk</option>
                <option>Funk</option>
                <option>Funk/Phonk Fusion</option>
                <option>Other</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="dNotes">Notes</label>
              <textarea id="dNotes" name="dNotes" placeholder="Anything we should know" />
            </div>
            <button type="submit" className="btn btn-primary" style={{ width: '100%' }} disabled={sending}>
              {sending ? 'Sending…' : 'Send Demo'}
            </button>
          </form>

          <div className="card terms-card" data-reveal>
            <h3>The Deal</h3>
            <ul className="terms-list">
              <li>
                <span className="dot"></span>
                <span>
                  <b>Distribution</b> — full digital distribution across every major platform.
                </span>
              </li>
              <li>
                <span className="dot"></span>
                <span>
                  <b>80 / 20 split</b> — artist keeps 80%, label takes 20%, no hidden costs.
                </span>
              </li>
              <li>
                <span className="dot"></span>
                <span>
                  <b>Free cover art</b> — original artwork made in-house for every release.
                </span>
              </li>
              <li>
                <span className="dot"></span>
                <span>
                  <b>Promo push</b> — playlist pitching and social promotion at launch.
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className={`toast${toast ? ' show' : ''}`} role="status">
        {toast}
      </div>
    </section>
  )
}
