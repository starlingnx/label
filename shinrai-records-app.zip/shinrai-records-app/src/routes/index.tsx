import { createFileRoute, Link } from '@tanstack/react-router'
import { useReveal } from '../hooks/useReveal'
import { releases, playlists, partners, stats } from '../data'
import ReleaseCard from '../components/ReleaseCard'
import PlaylistCard from '../components/PlaylistCard'
import StatCounter from '../components/StatCounter'
import SectionHeading from '../components/SectionHeading'
import Marquee from '../components/Marquee'

export const Route = createFileRoute('/')({
  head: () => ({
    meta: [
      { title: 'Shinrai Records — Independent Record Label' },
      {
        name: 'description',
        content: 'Shinrai Records — an independent funk and phonk label. Listen to the roster, browse releases, and submit your demo.',
      },
    ],
  }),
  component: Home,
})

function Home() {
  useReveal()

  return (
    <>
      <section className="hero">
        <div className="container">
          <div className="eyebrow">Independent Record Label</div>
          <h1 className="h1">
            MUSIC, BUILT ON <em>TRUST</em>
          </h1>
          <p>
            Shinrai is a home for funk and phonk artists who want a label that actually answers —
            fast decisions, fair splits, real promotion.
          </p>
          <div className="btn-row">
            <Link to="/submit-demo" className="btn btn-primary">
              Submit Demo
            </Link>
            <Link to="/artists" className="btn btn-outline">
              Explore Artists
            </Link>
          </div>
          <div className="scrollcue">
            SCROLL
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
        </div>
      </section>

      <div className="container" data-reveal>
        <p className="intro">
          Shinrai — 信頼, Japanese for <b style={{ color: 'var(--text)' }}>trust</b> — was started
          by people tired of demo submissions vanishing into silence. Every artist on the roster
          gets a real answer, a real release plan, and a real cut of what their music earns.
        </p>
      </div>

      <div className="container stats" data-reveal>
        {stats.map((s) => (
          <StatCounter key={s.label} target={s.target} label={s.label} />
        ))}
      </div>

      <div className="container" style={{ marginTop: 100 }} data-reveal>
        <SectionHeading
          title={
            <>
              Recent <em>Releases</em>
            </>
          }
          subtitle="Fresh off the desk"
        />
        <div className="grid grid-3">
          {releases.map((r) => (
            <ReleaseCard key={r.t} {...r} />
          ))}
        </div>
      </div>

      <div className="container" style={{ marginTop: 80 }} data-reveal>
        <SectionHeading
          title={
            <>
              Curated <em>Playlists</em>
            </>
          }
        />
        <div className="grid grid-3">
          {playlists.map((p) => (
            <PlaylistCard key={p.t} {...p} />
          ))}
        </div>
      </div>

      <Marquee items={partners} />

      <div className="container">
        <div className="cta-band" data-reveal>
          <h2>
            Got a track worth <em>hearing</em>?
          </h2>
          <p>Send it over — every submission gets heard within two weeks.</p>
          <Link to="/submit-demo" className="btn btn-primary">
            Submit Your Demo
          </Link>
        </div>
      </div>
    </>
  )
}
