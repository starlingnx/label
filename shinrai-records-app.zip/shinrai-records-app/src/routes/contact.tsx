import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useRef, useState } from 'react'
import { useReveal } from '../hooks/useReveal'
import { submitContactFn } from '../server/submitContact'

export const Route = createFileRoute('/contact')({
  head: () => ({
    meta: [
      { title: 'Contact — Shinrai Records' },
      { name: 'description', content: 'Get in touch with Shinrai Records.' },
    ],
  }),
  component: Contact,
})

function Contact() {
  useReveal()
  const [toast, setToast] = useState<string | null>(null)
  const [sending, setSending] = useState(false)
  const timer = useRef<ReturnType<typeof setTimeout>>()

  function fireToast(msg: string) {
    setToast(msg)
    clearTimeout(timer.current)
    timer.current = setTimeout(() => setToast(null), 3200)
  }
  useEffect(() => () => clearTimeout(timer.current), [])

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = e.currentTarget
    const data = {
      name: (form.elements.namedItem('cName') as HTMLInputElement).value,
      email: (form.elements.namedItem('cEmail') as HTMLInputElement).value,
      message: (form.elements.namedItem('cMsg') as HTMLTextAreaElement).value,
    }
    setSending(true)
    try {
      await submitContactFn({ data })
      fireToast('Message sent — thanks for reaching out.')
      form.reset()
    } catch {
      fireToast('Something went wrong — please try again.')
    } finally {
      setSending(false)
    }
  }

  return (
    <section className="page">
      <div className="container contact-wrap">
        <div className="s-title" data-reveal>
          Get In <em>Touch</em>
        </div>
        <a href="mailto:support.shinrairecords@gmail.com" className="contact-email" data-reveal>
          support.shinrairecords@gmail.com
        </a>
        <div className="social-row" data-reveal>
          <a href="#">Instagram</a>
          <a href="#">SoundCloud</a>
          <a href="#">Spotify</a>
          <a href="#">TikTok</a>
        </div>
        <form data-reveal style={{ maxWidth: 460 }} onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="cName">Name</label>
            <input id="cName" name="cName" required />
          </div>
          <div className="field">
            <label htmlFor="cEmail">Email</label>
            <input id="cEmail" name="cEmail" type="email" required />
          </div>
          <div className="field">
            <label htmlFor="cMsg">Message</label>
            <textarea id="cMsg" name="cMsg" required />
          </div>
          <button type="submit" className="btn btn-primary" style={{ width: '100%' }} disabled={sending}>
            {sending ? 'Sending…' : 'Send Message'}
          </button>
        </form>
      </div>

      <div className={`toast${toast ? ' show' : ''}`} role="status">
        {toast}
      </div>
    </section>
  )
}
