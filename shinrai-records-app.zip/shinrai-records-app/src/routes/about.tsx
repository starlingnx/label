import { createFileRoute } from '@tanstack/react-router'
import { useReveal } from '../hooks/useReveal'

export const Route = createFileRoute('/about')({
  head: () => ({
    meta: [
      { title: 'About — Shinrai Records' },
      { name: 'description', content: 'The story, values, and team behind Shinrai Records.' },
    ],
  }),
  component: About,
})

function About() {
  useReveal()

  return (
    <section className="page">
      <div className="container">
        <div className="s-title" data-reveal style={{ marginBottom: 30 }}>
          Our <em>Story</em>
        </div>
        <p className="about-story" data-reveal>
          Shinrai started in a bedroom studio with two things: a shared folder of unreleased funk
          loops and a running list of labels that had gone quiet on friends&apos; demos. So we
          built the label we wished existed —{' '}
          <b>fast replies, honest splits, and promotion that actually moves the needle.</b> No
          shelved masters, no fine print.
        </p>
        <div className="grid grid-3" data-reveal>
          <div className="card value-card">
            <div className="card-title">Direct Communication</div>
            <p>You hear from a person, not a form-letter, within two weeks of submitting.</p>
          </div>
          <div className="card value-card">
            <div className="card-title">Fair Splits</div>
            <p>80/20 in the artist&apos;s favor, every release, no exceptions or hidden fees.</p>
          </div>
          <div className="card value-card">
            <div className="card-title">Real Promotion</div>
            <p>Playlist pitching, social push, and cover art — not just a distribution link.</p>
          </div>
        </div>
        <div className="team-blurb" data-reveal>
          Run by a small team of producers and A&amp;R who still make music themselves — we sign
          what we&apos;d want in our own rotation.
        </div>
      </div>
    </section>
  )
}
