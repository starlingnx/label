import { createFileRoute } from '@tanstack/react-router'
import { useReveal } from '../hooks/useReveal'
import { artists } from '../data'

export const Route = createFileRoute('/artists')({
  head: () => ({
    meta: [
      { title: 'Artists — Shinrai Records' },
      { name: 'description', content: 'The Shinrai Records roster — funk and phonk artists signed to the label.' },
    ],
  }),
  component: Artists,
})

function Artists() {
  useReveal()

  return (
    <section className="page">
      <div className="container">
        <div className="s-title" data-reveal style={{ marginBottom: 30 }}>
          The <em>Roster</em>
        </div>
        <div className="grid grid-3" data-reveal>
          {artists.map((a) => (
            <div className="card artist-card" key={a.n}>
              <div className={`avatar ${a.c}`}>
                {a.n
                  .split(' ')
                  .map((w) => w[0])
                  .join('')
                  .slice(0, 2)}
              </div>
              <div className="artist-name">{a.n}</div>
              <div className="artist-genre">{a.g}</div>
              <div className="artist-links">
                <a href="#">Spotify</a>
                <a href="#">Instagram</a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
