# Shinrai Records — TanStack Start site

## Setup

```
npm install
npm run dev
```

Opens at http://localhost:3000. `src/routeTree.gen.ts` is generated automatically the
first time you run `dev` or `build` — you don't need to write it by hand.

## Structure

- `vite.config.ts` — TanStack Start's Vite plugin (current setup — not the older `app.config.ts`)
- `src/routes/__root.tsx` — shared layout (Nav, Footer, fonts, global CSS)
- `src/routes/index.tsx` — Home
- `src/routes/about.tsx`, `artists.tsx`, `submit-demo.tsx`, `contact.tsx` — the other pages
- `src/components/` — Nav, Footer, SectionHeading, ReleaseCard, PlaylistCard, StatCounter, Marquee
- `src/server/submitDemo.ts`, `submitContact.ts` — server functions the two forms call
- `src/data.ts` — releases, playlists, artists, partners, stats (swap in your real ones here)
- `src/styles.css` — design tokens (colors, fonts, spacing) — no hardcoded colors in components

## Forms — one step left before launch

Both forms now submit to real server functions (`src/server/submitDemo.ts` and
`submitContact.ts`), so the round-trip works and you'll see submissions logged in your
server console. What's still missing is the last hop to an actual inbox. Pick one:

1. **Email API** — Resend, Postmark, or SendGrid. Add your API key to `.env` (see
   `.env.example`), then call it inside the two `handler()` functions and send to
   support.shinrairecords@gmail.com.
2. **Form backend** — Formspree or Basin. POST the `data` object to their endpoint instead.

## Deploy

Recommended hosts (all handle TanStack Start's server layer for you): **Netlify**
(a starter `netlify.toml` is included), **Vercel**, or **Cloudflare**. Push this to a
GitHub repo, import it on whichever host you pick, and it builds with `npm run build`
automatically on every push.

## Other notes

- Dependency versions in `package.json` are current as of when this was generated —
  run `npm install` and check https://tanstack.com/start for anything newer.
- Artist/release art is CSS gradient placeholders — drop real cover art and artist
  photos into `src/data.ts` / an `assets` folder when ready.
